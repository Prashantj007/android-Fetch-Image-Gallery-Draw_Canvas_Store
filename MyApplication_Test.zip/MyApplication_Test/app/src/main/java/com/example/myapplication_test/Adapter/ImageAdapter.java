package com.example.myapplication_test.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.example.myapplication_test.R;

import java.io.FileNotFoundException;
import java.util.List;



/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    Bitmap bitmap;
    List<Uri> mlisturi;

    public ImageAdapter(Context c, List<Uri> listuri) {
        mContext = c;
        mlisturi = listuri;
    }

    @Override
    public int getCount() {
        return mlisturi.size();
    }

    @Override
    public Object getItem(int i) {
        return mlisturi.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView imageView = new ImageView(mContext);
        imageView.setPadding(5,5,5,5);
        Uri uri = mlisturi.get(i);
        bitmap = decodeSampledBitmapFromUri(uri, 320, 200);
        imageView.setImageBitmap(bitmap);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new GridView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        imageView.setBackgroundResource(R.drawable.bg_button);
        return imageView;
    }

    public Bitmap decodeSampledBitmapFromUri(Uri uri,
                                             int reqWidth, int reqHeight) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeStream(mContext.getContentResolver().openInputStream(uri), null, options);
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(mContext.getContentResolver().openInputStream(uri), null, options);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            System.gc();
        }
        return null;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            if (width > height) {
                inSampleSize = Math.round((float) height / (float) reqHeight);
            } else {
                inSampleSize = Math.round((float) width / (float) reqWidth);
            }
        }
        return inSampleSize;
    }
}
