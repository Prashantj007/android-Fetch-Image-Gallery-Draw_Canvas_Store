package com.example.myapplication_test.CustomView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.example.myapplication_test.Activity.SingleCropActivity;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Prashant Jadhav on 08/02/2020.
 */
public class DrawImageView extends ImageView implements View.OnTouchListener {
    Paint mPaint;
    Canvas mCanvas;
    Path mPath;
    Paint mBitmapPaint;
    Bitmap imgBitmap;
    List<Path> paths;
    SingleCropActivity singleCropActivity;
    private float mX, mY;
    private static final float TOUCH_TOLERANCE = 4;

    public DrawImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        singleCropActivity = (SingleCropActivity) context;
        init();
    }

    private void init() {
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(0xFF0000FF);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeWidth(5);
        mPath = new Path();
        mBitmapPaint = new Paint();
        mBitmapPaint.setColor(Color.BLUE);
        paths = new ArrayList<>();
        Drawable imgDrawable = getDrawable();
        imgBitmap = ((BitmapDrawable) imgDrawable).getBitmap();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        imgBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(imgBitmap);
    }

    @Override
    public void draw(Canvas canvas) {
        // TODO Auto-generated method stub
        super.draw(canvas);
        // canvas.clipPath(mPath, Region.Op.DIFFERENCE);
        canvas.clipPath(mPath);
        canvas.drawBitmap(imgBitmap, 0, 0, mBitmapPaint);
        canvas.drawPath(mPath, mPaint);
    }

    public void onDoneClick() {
//        Toast.makeText(singleCropActivity, "Done Click", Toast.LENGTH_SHORT).show();
        //imgBitmap = GetBitmapClippedCircle(mBitmap);

    }


    private void touch_start(float x, float y) {
        //mPath.reset();
        mPath.moveTo(x, y);
        mX = x;
        mY = y;
    }

    private void touch_move(float x, float y) {
        float dx = Math.abs(x - mX);
        float dy = Math.abs(y - mY);
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
            mX = x;
            mY = y;
        }
    }

    private void touch_up() {
        mPath.lineTo(mX, mY);
        // paths.add(mPath);
        // commit the path to our offscreen
        mCanvas.drawPath(mPath, mPaint);
        //mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        // kill this so we don't double draw
        mPath.reset();
        // mPath= new Path();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        float eventX = event.getX();
        float eventY = event.getY();
        float[] eventXY = new float[]{eventX, eventY};

        Matrix invertMatrix = new Matrix();
        getImageMatrix().invert(invertMatrix);

        invertMatrix.mapPoints(eventXY);
        int x1 = Integer.valueOf((int) eventXY[0]);
        int y1 = Integer.valueOf((int) eventXY[1]);

        if (x1 < 0) {
            x1 = 0;
        } else if (x1 > imgBitmap.getWidth() - 1) {
            x1 = imgBitmap.getWidth() - 1;
        }

        if (y1 < 0) {
            y1 = 0;
        } else if (y1 > imgBitmap.getHeight() - 1) {
            y1 = imgBitmap.getHeight() - 1;
        }

        int touchedRGB = imgBitmap.getPixel(x1, y1);
        int redValue = Color.red(touchedRGB);
        int blueValue = Color.blue(touchedRGB);
        int greenValue = Color.green(touchedRGB);
        Log.d("Pixels", "red blue green value-" + String.valueOf(redValue) + " " + String.valueOf(greenValue) + " " + String.valueOf(blueValue) + " " + Integer.toHexString(touchedRGB));


        float x = event.getX();
        float y = event.getY();
        Log.d("Points", String.valueOf(x) + " " + String.valueOf(y));
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touch_start(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                touch_move(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                touch_up();
                invalidate();
                break;
        }
        return true;
    }

    public Bitmap GetBitmapClippedCircle() {
        Bitmap croppedBitmap = Bitmap.createBitmap(imgBitmap, 10, 10, 200, 200);
        Canvas canvas = new Canvas(croppedBitmap);

        // Create a path
        Path path = new Path();
        path.setFillType(Path.FillType.INVERSE_EVEN_ODD);
        path.moveTo(0, 0);
        path.moveTo(0, 100);
        path.moveTo(100, 0);
        path.moveTo(0, 0);

        Paint paint = new Paint();
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));

        canvas.drawPath(path, paint);
        return croppedBitmap;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return false;
    }
}