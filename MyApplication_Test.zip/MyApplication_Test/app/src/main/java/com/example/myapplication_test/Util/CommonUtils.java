package com.example.myapplication_test.Util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.example.myapplication_test.Model.ModelUri;
import com.google.gson.Gson;

/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

public class CommonUtils {

    public static final String PREFS_NAME = "TEST_APP";
    public static final String FAVORITES = "TEST_LIST";

    public CommonUtils() {
        super();
    }

    // This four methods are used for maintaining favorites.
    public void saveFavorites(Context context, List<ModelUri> favorites) {
        SharedPreferences settings;
        Editor editor;

        settings = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);
        editor = settings.edit();

        Gson gson = new Gson();
        String jsonFavorites = gson.toJson(favorites);

        editor.putString(FAVORITES, jsonFavorites);

        editor.commit();
    }

    public void addFavorite(Context context, ModelUri product) {
        List<ModelUri> favorites = getFavorites(context);
        if (favorites == null)
            favorites = new ArrayList<ModelUri>();
        favorites.add(product);
        saveFavorites(context, favorites);
    }

    public void removeFavorite(Context context, ModelUri product) {
        ArrayList<ModelUri> favorites = getFavorites(context);
        if (favorites != null) {
            favorites.remove(product);
            saveFavorites(context, favorites);
        }
    }

    public ArrayList<ModelUri> getFavorites(Context context) {
        SharedPreferences settings;
        List<ModelUri> favorites;

        settings = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);

        if (settings.contains(FAVORITES)) {
            String jsonFavorites = settings.getString(FAVORITES, null);
            Gson gson = new Gson();
            ModelUri[] favoriteItems = gson.fromJson(jsonFavorites,
                    ModelUri[].class);

            favorites = Arrays.asList(favoriteItems);
            favorites = new ArrayList<ModelUri>(favorites);
        } else
            return null;

        return (ArrayList<ModelUri>) favorites;
    }
}

