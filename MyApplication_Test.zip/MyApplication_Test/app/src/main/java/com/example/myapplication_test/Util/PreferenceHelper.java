package com.example.myapplication_test.Util;


import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PreferenceHelper {
    public final static String TAG = "Vitaleague";
    public static final String PREFERENCESNAME = "Vitaleague";

    public static final String EXTRA_PARAMS_IMAGE_URI_PATH = "imageuripath";
    public static final String PARA_TOTAL_COUNT = "totalcount";
    public static final int PERMISSION_REQUEST_CAMERA = 320;
    public static final int PERMISSION_REQUEST_READ_WRITE = 310;

    public static final String PARA_REFERENCE_AREA_RGB1 = "reference_area_rgb1";
    public static final String PARA_REFERENCE_AREA_RGB2 = "reference_area_rgb2";
    public static final String PARA_REFERENCE_AREA_RGB3 = "reference_area_rgb3";
    public static final String PARA_REFERENCE_AREA_RGB4 = "reference_area_rgb4";
    public static final String PARA_REFERENCE_AREA_RGB5 = "reference_area_rgb5";

    public static void setPreferenceValue(Context context, String key, int value) {
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCESNAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static int getIntPreferenceValue(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCESNAME,
                Context.MODE_PRIVATE);
        return prefs.getInt(key, -1);
    }

    public static void setPreferenceValue(Context context, String key,
                                          String value) {
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCESNAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getStringPreferenceValue(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCESNAME,
                Context.MODE_PRIVATE);

        return prefs.getString(key, "");
    }

}
