package com.example.myapplication_test.CustomView;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.myapplication_test.Activity.SingleCropActivity;
import com.example.myapplication_test.Util.ImageUtils;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Prashant Jadhav on 08/02/2020.
 */

public class SingleDrawView extends View implements View.OnTouchListener {
    private static final String TAG = "SingleDrawView";
    private Paint paint;
    boolean flgPathDraw = true;
    Point mfirstpoint = null;
    boolean bfirstpoint = false;
    Point mlastpoint = null;
    SingleCropActivity mContext;
    List<Point> points;
    Bitmap bmp;
    boolean isSelected = false;
    Uri mUri;
    int width;
    int height;

    private ScaleGestureDetector mScaleDetector;
    private float mScaleFactor = 1.f;
    private float scalePointX;
    private float scalePointY;
    private Rect rect;
    private float mPosX;
    private float mPosY;
    private float mLastTouchX;
    private float mLastTouchY;


    public SingleDrawView(SingleCropActivity c, Uri uri) {
        super(c);
        mContext = c;
        mUri = uri;
        mScaleDetector = new ScaleGestureDetector(mContext, new ScaleListener());
        setFocusable(true);
        setFocusableInTouchMode(true);

        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);
        paint.setColor(Color.RED);
        this.setOnTouchListener(this);
        points = new ArrayList<Point>();
        bfirstpoint = false;
        bmp = mContext.getBitmap();
    }

    public void onDoneClick() {
        if (isSelected) {
            bfirstpoint = false;
            new CropAsync().execute();
        } else {
            showcropdialog();
        }
    }


    @Override
    protected void onDraw(Canvas canvas) {
        if (SingleCropActivity.mode == SingleCropActivity.ZOOM || SingleCropActivity.mode == SingleCropActivity.NONE || SingleCropActivity.mode == SingleCropActivity.DRAG) {

            canvas.save();
            canvas.scale(mScaleFactor, mScaleFactor, scalePointX, scalePointY);
            canvas.translate(mPosX, mPosY);
            rect = canvas.getClipBounds();
            width = this.getWidth();
            height = this.getHeight();

            bmp = ImageUtils.getScaledBitmap(bmp, width, height);
            ImageUtils.setBitmapInCanvas(bmp, canvas, width, height, paint);

        } else if (SingleCropActivity.mode == SingleCropActivity.DRAW) {

            canvas.save();
            canvas.scale(mScaleFactor, mScaleFactor, scalePointX, scalePointY);
            canvas.translate(mPosX, mPosY);
            rect = canvas.getClipBounds();
            width = this.getWidth();
            height = this.getHeight();

            bmp = ImageUtils.getScaledBitmap(bmp, width, height);
            ImageUtils.setBitmapInCanvas(bmp, canvas, width, height, paint);

            Path path = new Path();
            boolean first = true;
            for (int i = 0; i < points.size(); i += 2) {
                Point point = points.get(i);
                if (first) {
                    first = false;
                    path.moveTo(point.x, point.y);
                } else if (i < points.size() - 1) {
                    Point next = points.get(i + 1);
                    path.quadTo(point.x, point.y, next.x, next.y);
                } else {
                    mlastpoint = points.get(i);
                    path.lineTo(point.x, point.y);
                }
            }
            canvas.drawPath(path, paint);
        }
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        mScaleDetector.onTouchEvent(event);
        Point point = new Point();
        point.x = (int) ((int) event.getX() / mScaleFactor + rect.left);
        point.y = (int) ((int) event.getY() / mScaleFactor + rect.top);
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:

                if (SingleCropActivity.mode == SingleCropActivity.DRAW) {
                    if (!flgPathDraw) {
                        resetView();
                    }
                } else {
                    SingleCropActivity.mode = SingleCropActivity.DRAG;
                    final float x = (event.getX() - scalePointX) / mScaleFactor;
                    final float y = (event.getY() - scalePointY) / mScaleFactor;

                    mLastTouchX = x;
                    mLastTouchY = y;

                    resetView();
                }
                break;

            case MotionEvent.ACTION_POINTER_DOWN: {
                SingleCropActivity.mode = SingleCropActivity.ZOOM;
                final float x = (event.getX() - scalePointX) / mScaleFactor;
                final float y = (event.getY() - scalePointY) / mScaleFactor;

                mLastTouchX = x;
                mLastTouchY = y;

                resetView();
                break;
            }

            case MotionEvent.ACTION_MOVE: {
                if (SingleCropActivity.mode == SingleCropActivity.DRAW) {
                    if (flgPathDraw) {
                        if (bfirstpoint) {
                            if (comparepoint(mfirstpoint, point)) {
                                points.add(mfirstpoint);
                                flgPathDraw = false;
                            } else {
                                points.add(point);
                            }
                        } else {
                            points.add(point);
                        }
                        if (!(bfirstpoint)) {
                            mfirstpoint = point;
                            bfirstpoint = true;
                            isSelected = true;
                        }
                    }
                    invalidate();
                } else if (SingleCropActivity.mode == SingleCropActivity.ZOOM || SingleCropActivity.mode == SingleCropActivity.DRAG) {
                    final float x = (event.getX() - scalePointX) / mScaleFactor;
                    final float y = (event.getY() - scalePointY) / mScaleFactor;

                    if (!mScaleDetector.isInProgress()) {
                        final float dx = x - mLastTouchX;
                        final float dy = y - mLastTouchY;
                        mPosX += dx;
                        mPosY += dy;
                        invalidate();
                    }
                    mLastTouchX = x;
                    mLastTouchY = y;
                    resetView();
                }

                break;
            }
            case MotionEvent.ACTION_POINTER_UP:
                resetView();
                SingleCropActivity.mode = SingleCropActivity.DRAG;
                mContext.onDrawClick(false);
                break;

            case MotionEvent.ACTION_UP:
                if (SingleCropActivity.mode == SingleCropActivity.DRAW) {
                    mlastpoint = point;
                    if (flgPathDraw) {
                        Log.d(TAG, "" + points.size());
                        if (points.size() > 12) {
                            if (!comparepoint(mfirstpoint, mlastpoint)) {
                                flgPathDraw = false;
                                points.add(mfirstpoint);
                            }
                        }else{
                            resetView();
                        }
                    }
                } else if (SingleCropActivity.mode == SingleCropActivity.ZOOM || SingleCropActivity.mode == SingleCropActivity.DRAG) {
                    resetView();
                    mLastTouchX = 0;
                    mLastTouchY = 0;
                    invalidate();
                }
                if (SingleCropActivity.mode != SingleCropActivity.DRAW) {
                    SingleCropActivity.mode = SingleCropActivity.DRAG;
                }
                break;
        }
        return true;
    }

    private boolean comparepoint(Point first, Point current) {
        int left_range_x = (int) (current.x - 3);
        int left_range_y = (int) (current.y - 3);

        int right_range_x = (int) (current.x + 3);
        int right_range_y = (int) (current.y + 3);

        if ((left_range_x < first.x && first.x < right_range_x)
                && (left_range_y < first.y && first.y < right_range_y)) {
            if (points.size() < 10) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public void resetView() {
        points.clear();
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);
        flgPathDraw = true;
        bfirstpoint = false;
        mlastpoint = null;
        mfirstpoint = null;
        invalidate();
    }


    private void showcropdialog() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        bfirstpoint = false;
                        resetView();
                        dialog.dismiss();
                        break;

                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setMessage("Please select the reference area on the image")
                .setPositiveButton("Ok", dialogClickListener)
                .setNegativeButton("", dialogClickListener)
                .show()
                .setCancelable(false);
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            Log.d(TAG, "In ScaleListener onScale");

            mScaleFactor *= detector.getScaleFactor();
            scalePointX = detector.getFocusX();
            scalePointY = detector.getFocusY();

            mScaleFactor = Math.max(1.0f, Math.min(mScaleFactor, 5.0f));
            invalidate();
            return true;
        }
    }


    private class CropAsync extends AsyncTask<Void, Void, Bitmap> {
        ProgressDialog dialog;


        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(getContext());
            dialog.setMessage("Cropping...");
            dialog.show();
        }

        @Override
        protected Bitmap doInBackground(Void... voids) {
            Bitmap resultBitmap = setCropImage(true);
            return resultBitmap;
        }

        private Bitmap setCropImage(boolean crop) {
            try {
                Bitmap bitmap2;
                bitmap2 = ImageUtils.decodeSampledBitmapFromUri(mUri, width, height, mContext);
                bitmap2 = ImageUtils.rotateBitmap(bitmap2);
                bitmap2 = ImageUtils.getScaledBitmap(bitmap2, width, height);


                Bitmap resultingImage = Bitmap.createBitmap(bitmap2.getWidth(), bitmap2.getHeight(), bitmap2.getConfig());

                Canvas canvas = new Canvas(resultingImage);
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

                Path path = new Path();
                for (int i = 0; i < points.size(); i++) {
                    path.lineTo(points.get(i).x, points.get(i).y);
                }
                canvas.drawPath(path, paint);
                if (crop) {
                    paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                } else {
                    paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                }
                ImageUtils.setBitmapInCanvas(bitmap2, canvas, width, height, paint);
                Bitmap croppedResultBitmap = ImageUtils.CropBitmapTransparency(resultingImage);
                bitmap2 = null;
                resultingImage = null;
                return croppedResultBitmap;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(Bitmap croppedResultBitmap) {
            super.onPostExecute(croppedResultBitmap);

            if(croppedResultBitmap!=null){
                if (ImageUtils.isBitmapStored(croppedResultBitmap, "reference", mContext)) {
                    dialog.dismiss();
                    Toast.makeText(mContext, "Image saved successfully, Please check in gallery", Toast.LENGTH_LONG).show();
                    mContext.afterCrop();
                } else {
                    dialog.dismiss();
                    Toast.makeText(mContext, "Sorry, Please select new image which is not crop", Toast.LENGTH_SHORT).show();
                }
            }else {
                dialog.dismiss();
                Toast.makeText(mContext, "Sorry, Please select new image which is not crop", Toast.LENGTH_SHORT).show();
            }

        }
    }
}