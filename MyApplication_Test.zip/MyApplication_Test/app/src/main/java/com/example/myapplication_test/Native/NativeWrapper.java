package com.example.myapplication_test.Native;

import android.util.Log;



/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

public class NativeWrapper {

    // public static native int sayHello(int i,int j);

    public static native double[] processImage(String rgbValue, String referenceimg1, String referenceimg2, String referenceimg3, String referenceimg4, String referenceimg5, String targetimg);


}
