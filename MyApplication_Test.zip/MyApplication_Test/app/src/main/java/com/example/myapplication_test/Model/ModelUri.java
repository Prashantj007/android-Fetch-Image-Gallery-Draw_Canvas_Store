package com.example.myapplication_test.Model;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

@SuppressLint("ParcelCreator")
public class ModelUri implements Parcelable {

    private String mStringUri;

    public ModelUri(Parcel in) {
        mStringUri = in.readString();
    }

    public static final Creator<ModelUri> CREATOR = new Creator<ModelUri>() {
        @Override
        public ModelUri createFromParcel(Parcel in) {
            return new ModelUri(in);
        }

        @Override
        public ModelUri[] newArray(int size) {
            return new ModelUri[size];
        }
    };

    public ModelUri() {

    }

    public String getmStringUri() {
        return mStringUri;
    }

    public void setmStringUri(String mStringUri) {
        this.mStringUri = mStringUri;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mStringUri);
    }
}
