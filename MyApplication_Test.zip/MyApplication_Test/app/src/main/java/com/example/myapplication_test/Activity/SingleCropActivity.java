package com.example.myapplication_test.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myapplication_test.CustomView.SingleDrawView;
import com.example.myapplication_test.R;
import com.example.myapplication_test.Util.ImageUtils;
import com.example.myapplication_test.Util.PreferenceHelper;


/**
 * Created by Prashant Jadhav on 08/02/2020.
 */
public class SingleCropActivity extends AppCompatActivity implements View.OnClickListener {

    Uri mUri;
    private TextView toolbarTitle, toolbarSubtitle, toolbarMessage, tvSubmit;
    Bitmap bmp;
    LinearLayout llimage;
    SingleDrawView singleDrawView;
    Button btnDraw, btnClick,btnErase;

    // We can be in one of these 4 states
    public static final int NONE = 0;
    public static final int DRAG = 4;
    public static final int DRAW = 1;
    public static final int ZOOM = 3;
    boolean isDrawClick = true;
    public static int mode = NONE;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_crop);
        getIntentData();
        setBitmap();
        initToolbar();
        initView();
    }

    private void initView() {
        singleDrawView = new SingleDrawView(this, mUri);
        llimage = (LinearLayout) findViewById(R.id.llimage);
        llimage.addView(singleDrawView);
        btnDraw = (Button) findViewById(R.id.btnDraw);
        btnClick = (Button) findViewById(R.id.btnClick);
        btnErase = (Button) findViewById(R.id.btnErase);
        btnDraw.setOnClickListener(this);
        btnClick.setOnClickListener(this);
        btnErase.setOnClickListener(this);
    }


    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar_with_subtitle);

        toolbarTitle = (TextView) findViewById(R.id.toolbar_title);
        toolbarTitle.setVisibility(View.VISIBLE);
        setToolbarTitle();
        //toolbarTitle.setText("Step 1.1");
        toolbarTitle.setTextColor(getResources().getColor(R.color.white));
        toolbarSubtitle = (TextView) findViewById(R.id.toolbar_subtitle);
        toolbarSubtitle.setVisibility(View.GONE);
        toolbarMessage = (TextView) findViewById(R.id.toolbar_message);
        toolbarMessage.setVisibility(View.GONE);
        tvSubmit = (TextView) findViewById(R.id.tvSubmit);
        tvSubmit.setVisibility(View.VISIBLE);
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  int count = PreferenceHelper.getIntPreferenceValue(SingleCropActivity.this, PreferenceHelper.PARA_TOTAL_COUNT);
                if (count >= 5) {
                    if (checkRGBDialogValues()) {
                        goToMultiCropActivity();
                    }
                } else {*/
                    singleDrawView.onDoneClick();

            }
        });
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
    }

    private void setToolbarTitle() {
        int count = PreferenceHelper.getIntPreferenceValue(SingleCropActivity.this, PreferenceHelper.PARA_TOTAL_COUNT);
        if (count == 0) {
            toolbarTitle.setText("Step 1.1");
        } else if (count == 1) {
            toolbarTitle.setText("Step 1.2");
        } else if (count == 2) {
            toolbarTitle.setText("Step 1.3");
        } else if (count == 3) {
            toolbarTitle.setText("Step 1.4");
        } else if (count == 4) {
            toolbarTitle.setText("Step 1.5");
        }
    }

    private void goToMultiCropActivity() {
       /* Intent intent = new Intent(SingleCropActivity.this, MultipleCropActivity.class);
        intent.putExtra(PreferenceHelper.EXTRA_PARAMS_IMAGE_URI_PATH, mUri.toString());
        startActivity(intent);*/
    }

    public void afterCrop() {
        int count = PreferenceHelper.getIntPreferenceValue(this, PreferenceHelper.PARA_TOTAL_COUNT);
        ++count;
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_TOTAL_COUNT, count);
        if (count >= 5) {
            if (checkRGBDialogValues()) {
                goToMultiCropActivity();
            }
        } else {
            Intent intent = new Intent(this, SingleCropActivity.class);
            intent.putExtra(PreferenceHelper.EXTRA_PARAMS_IMAGE_URI_PATH, mUri.toString());
            startActivity(intent);
            finish();
        }
    }

    private boolean checkRGBDialogValues() {
        if (PreferenceHelper.getStringPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB1).equalsIgnoreCase("") || PreferenceHelper.getStringPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB2).equalsIgnoreCase("") || PreferenceHelper.getStringPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB3).equalsIgnoreCase("") || PreferenceHelper.getStringPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB4).equalsIgnoreCase("") || PreferenceHelper.getStringPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB5).equalsIgnoreCase("")) {
            return false;
        }
        return true;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnDraw:
                onDrawClick(isDrawClick);
                break;

            case R.id.btnClick:
               // rgbDialog.show();
                if(ImageUtils.storedUriList!=null && ImageUtils.storedUriList.size()>0){
                    Intent intent = new Intent(this, ResultActivity.class);
                    startActivity(intent);
                    finish();
                }else {
                    Toast.makeText(getApplicationContext(), "Sorry, Please save image.", Toast.LENGTH_SHORT).show();
                }

                break;

                case R.id.btnErase:
                    singleDrawView.resetView();
                break;
        }
    }

    public void onDrawClick(boolean flag) {
        if (flag) {
            isDrawClick = false;
            mode = DRAW;
            btnDraw.setBackgroundColor(getResources().getColor(R.color.green));
        } else {
            isDrawClick = true;
            mode = NONE;
            btnDraw.setBackgroundColor(getResources().getColor(R.color.gray));
        }
    }



    private void getIntentData() {
        try {
            if (getIntent() != null) {
                mUri = Uri.parse(getIntent().getStringExtra(PreferenceHelper.EXTRA_PARAMS_IMAGE_URI_PATH));
                Log.d("FilePath", mUri.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setBitmap() {
        try {
            BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
            bmpFactoryOptions.inJustDecodeBounds = false;
            bmpFactoryOptions.inPreferredConfig = Bitmap.Config.RGB_565;
            bmpFactoryOptions.inDither = true;
            bmp = BitmapFactory.decodeStream(getContentResolver().openInputStream(
                    mUri), null, bmpFactoryOptions);
            bmp = ImageUtils.rotateBitmap(bmp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public Bitmap getBitmap() {
        try {
            return bmp;
        } catch (Exception e) {

        }
        return null;
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
