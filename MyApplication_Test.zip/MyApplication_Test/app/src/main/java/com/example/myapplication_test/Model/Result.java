package com.example.myapplication_test.Model;

import java.io.Serializable;

/**
 * Created by Prashant Jadhav on 08/02/2020.
 */

public class Result implements Serializable{
    public double R;
    public double G;
    public double B;
    public String FileName;

    double[] rgb = new double[3];

    public double[] getRGB() {
        rgb[0] = R;
        rgb[1] = G;
        rgb[2] = B;
        return rgb;
    }
}
