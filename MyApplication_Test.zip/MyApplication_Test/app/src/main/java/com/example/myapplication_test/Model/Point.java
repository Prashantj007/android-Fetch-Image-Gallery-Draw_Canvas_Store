package com.example.myapplication_test.Model;

/**
 * Created by Prashant Jadhav on 08/02/2020.
 */
public class Point {
    public float dy;

    public float dx;
    public float x, y;

    @Override
    public String toString() {
        return x + ", " + y;
    }
}
