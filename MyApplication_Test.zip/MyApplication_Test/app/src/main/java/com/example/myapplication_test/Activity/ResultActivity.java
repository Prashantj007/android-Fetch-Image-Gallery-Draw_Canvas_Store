package com.example.myapplication_test.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myapplication_test.Adapter.ImageAdapter;
import com.example.myapplication_test.Model.Result;
import com.example.myapplication_test.R;
import com.example.myapplication_test.Util.ImageUtils;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Prashant Jadhav on 08/02/2020.
 */
public class ResultActivity extends AppCompatActivity {

    private TextView mTextViewToolbarTitle, toolbarSubtitle, toolbarMessage, tvSubmit, tvCount;
    ImageView referenceImage;
    Bitmap referenceBitmap;
    Result result;
    GridView gridView;
    List<Uri> listuri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        getIntentData();
        setView();
        initToolbar();
    }

    private void getIntentData() {
        if (getIntent() != null) {
            result = (Result) getIntent().getSerializableExtra("Result");
        }
    }

    private void setView() {
        tvCount = (TextView) findViewById(R.id.tvCount);
        referenceImage = (ImageView) findViewById(R.id.referenceImage);
        gridView = (GridView) findViewById(R.id.grdCroppedImages);

        if(ImageUtils.storedUriList!=null && ImageUtils.storedUriList.size()>0){
            Uri referenceUri = ImageUtils.storedUriList.get(0);
            Log.d("URI", referenceUri.toString());

            referenceBitmap = decodeSampledBitmapFromUri(referenceUri, 180, 180);
            referenceImage.setImageBitmap(referenceBitmap);

            listuri = new ArrayList<>();

            for (int i = 0; i < ImageUtils.storedUriList.size(); i++) {
                listuri.add(ImageUtils.storedUriList.get(i));
            }

            gridView.setAdapter(new ImageAdapter(ResultActivity.this, listuri));
        }else {
            Toast.makeText(getApplicationContext(), "Sorry, Please save image.", Toast.LENGTH_SHORT).show();

        }

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar_with_subtitle);
        mTextViewToolbarTitle = (TextView) findViewById(R.id.toolbar_title);
        mTextViewToolbarTitle.setVisibility(View.VISIBLE);
        mTextViewToolbarTitle.setText("Step 3");
        mTextViewToolbarTitle.setTextColor(getResources().getColor(R.color.white));
        toolbarSubtitle = (TextView) findViewById(R.id.toolbar_subtitle);
        toolbarSubtitle.setVisibility(View.GONE);
        toolbarMessage = (TextView) findViewById(R.id.toolbar_message);
        toolbarMessage.setVisibility(View.GONE);
        tvSubmit = (TextView) findViewById(R.id.tvSubmit);
        tvSubmit.setVisibility(View.VISIBLE);
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                ResultActivity.this.startActivity(intent);
            }
        });
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
    }

    public Bitmap decodeSampledBitmapFromUri(Uri uri,
                                             int reqWidth, int reqHeight) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, options);
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, options);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            System.gc();
        }
        return null;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            if (width > height) {
                inSampleSize = Math.round((float) height / (float) reqHeight);
            } else {
                inSampleSize = Math.round((float) width / (float) reqWidth);
            }
        }
        return inSampleSize;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
    }


}
