package com.example.myapplication_test.Activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.myapplication_test.R;
import com.example.myapplication_test.Util.ImageUtils;
import com.example.myapplication_test.Util.PreferenceHelper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

public class MainActivity extends Activity {

    Button btnstart;
    Button btnstartGallery;

    private Uri outputFileUri;

    public static final String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/VitaLeague/Images";

    private static final int CAMERA_PIC_REQUEST = 1;
    private static final String TAG = "MainActivity";
    private static final int GALLERY_PIC_REQUEST = 222;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
    }

    private void findView() {
     /*   btnstart = (Button) findViewById(R.id.btnstart);
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasCameraPermission()) {
                    ImageUtils.storedUriList.clear();
                    takePicture();
                }
            }
        });*/
        btnstartGallery = (Button) findViewById(R.id.btnstart2);
        btnstartGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasGalleryPermission()) {
                   // ImageUtils.storedUriList.clear();
                    openGallery();
                }
            }
        });
    }

    private boolean hasCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PreferenceHelper.PERMISSION_REQUEST_CAMERA);
            return false;
        } else
            return true;
    }

    private boolean hasGalleryPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PreferenceHelper.PERMISSION_REQUEST_READ_WRITE);

            return false;
        } else
            return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PreferenceHelper.PERMISSION_REQUEST_CAMERA: {
                //getting both camera and write permissions
                if (permissions.length == 2) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED
                            && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                        takePicture();
                    }
                }//getting one permission as other might be given
                else if (permissions.length == 1) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        takePicture();
                    }
                }
                return;
            }
            case PreferenceHelper.PERMISSION_REQUEST_READ_WRITE: {
                //both the read and write permission should be granted.
                //getting both read and write permissions
                if (permissions.length == 2) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED
                            && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                        openGallery();
                    }
                }//getting one permission as other might be given
                else if (permissions.length == 1) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        openGallery();
                    }
                }
                return;
            }
        }
    }

    File imageFile;

    private void openGallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(photoPickerIntent, GALLERY_PIC_REQUEST);
    }

    private void takePicture() {

        Date currentDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmm");
        String imagename = sdf.format(currentDate);
        boolean success = false;
        File file = new File(Environment.getExternalStorageDirectory() + "/VitaLeague");
        if (file.exists()) {
            success = true;
        } else {
            success = false;
        }
        imageFile = null;
        try {
            if (success) {
                imageFile = new File(file, imagename + ".png");
            } else {
                imageFile = new File(Environment.getExternalStorageDirectory(), imagename + ".png");
            }
            outputFileUri = Uri.fromFile(imageFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.v("IMAGE FILE PATH:", imageFile.getPath());

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (imageFile != null) {
            intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        }
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 1);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            switch (requestCode) {
                case CAMERA_PIC_REQUEST:

                    try {
                        setDefaultValueToPreference();
                        Intent i = new Intent(MainActivity.this, SingleCropActivity.class);
                        i.putExtra(PreferenceHelper.EXTRA_PARAMS_IMAGE_URI_PATH, outputFileUri.toString());
                        startActivity(i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case GALLERY_PIC_REQUEST:
                    try {
                        setDefaultValueToPreference();
                        Uri uri = data.getData();
                        Intent i = new Intent(MainActivity.this, SingleCropActivity.class);
                        i.putExtra(PreferenceHelper.EXTRA_PARAMS_IMAGE_URI_PATH, uri.toString());
                        startActivity(i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }

    private void setDefaultValueToPreference() {
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_TOTAL_COUNT, 0);
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB1, "");
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB2, "");
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB3, "");
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB4, "");
        PreferenceHelper.setPreferenceValue(this, PreferenceHelper.PARA_REFERENCE_AREA_RGB5, "");
    }

}
