package com.example.myapplication_test;

import android.app.Application;

/**
 * Created by Prashant Jadhav on 08/01/2020.
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
