package com.example.myapplication_test.Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Prashant Jadhav on 08/02/2020.
 */

public class CroppedPath {

    public Point firstPoint = null;
    public Point lastPoint = null;

    private List<Point> pointList = new ArrayList<>();

    public void setPointList(List<Point> pointList) {
        this.pointList = pointList;
    }

    public List<Point> getPointList() {
        return pointList;
    }

    public void addPoint(Point point) {
        pointList.add(point);
    }

    public void addFirstPoint(Point point) {
        firstPoint = point;
        pointList.add(firstPoint);
    }

    public void addLastPoint(Point point) {
        lastPoint = point;
        pointList.add(lastPoint);
    }

    public void clearPoints() {
        pointList.clear();
    }
}
