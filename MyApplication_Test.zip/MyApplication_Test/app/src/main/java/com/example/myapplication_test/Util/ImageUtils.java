package com.example.myapplication_test.Util;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;

import com.example.myapplication_test.Model.ModelUri;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Prashant Jadhav on 08/02/2020.
 */

public class ImageUtils {

    public static List<Uri> storedUriList = new ArrayList<>();

    public static Bitmap decodeSampledBitmapFromUri(Uri uri,
                                                    int reqWidth, int reqHeight, Context context) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri), null, options);
            // options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri), null, options);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            System.gc();
        }
        return null;
    }

    private static void storeUri(Uri uri, String imgname) {
        if (imgname.equalsIgnoreCase("reference")) {
            storedUriList.add(uri);
            /*if (storedUriList.size() == 0) {
                storedUriList.add(uri);
            } else {
                storedUriList.set(0, uri);
            }*/
        } else {
            storedUriList.add(uri);
        }
        Log.d("URI FILE PATH:", uri.toString());
    }


    public static boolean isBitmapStored(Bitmap resultingImage, String imgname, Context c) {
        File pictureFile = getOutPutMediaFile(imgname, c);
        if (pictureFile == null) {
            return false;
        }
        if (resultingImage != null) {
            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                resultingImage.compress(Bitmap.CompressFormat.PNG, 90, fos);
                storeUri(Uri.fromFile(pictureFile), imgname);
               /* CommonUtils commonUtils =new CommonUtils();
                ModelUri modelUri=new ModelUri();
                modelUri.setmStringUri((Uri.fromFile(pictureFile)));
                commonUtils.addFavorite(c, modelUri);*/
                fos.close();
                Log.d("TAG", "Cropped image Stored Successfully");
                return true;
            } catch (FileNotFoundException e) {
                Log.d("TAG", "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d("TAG", "Error accessing file: " + e.getMessage());
            }
        }
        return false;
    }

    private static File getOutPutMediaFile(String imgname, Context c) {
        Date currentDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
        String imagename = imgname + sdf.format(currentDate);

        File directory = new File(Environment.getExternalStorageDirectory() + "/Test");
        if (!directory.exists()) {
            directory.mkdir();
        }
        File imageFile = new File(directory, imagename + ".png");

        Log.d("IMAGE FILE PATH:", imageFile.toString());
        addImageToGallery(imageFile.toString(), c);
        return imageFile;
    }

    public static Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                int alpha = (sourceBitmap.getPixel(x, y) >> 24) & 255;
                if (alpha > 0)   // pixel is not 100% transparent
                {
                    if (x < minX)
                        minX = x;
                    if (x > maxX)
                        maxX = x;
                    if (y < minY)
                        minY = y;
                    if (y > maxY)
                        maxY = y;
                }
            }
        }
        if ((maxX < minX) || (maxY < minY))
            return null; // Bitmap is entirely transparent

        // crop bitmap to non-transparent area and return:
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1, (maxY - minY) + 1);
    }

    public static void addImageToGallery(final String filePath, final Context context) {

        ContentValues values = new ContentValues();

        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.MediaColumns.DATA, filePath);

        context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }

    public static void setBitmapInCanvas(Bitmap bmp, Canvas canvas, int viewWidth, int viewHeight, Paint paint) {
        Rect src = new Rect(0, 0, bmp.getWidth(), bmp.getHeight());
        int stX = (viewWidth - bmp.getWidth()) / 2;
        if (stX < 0) stX = 0;
        int stY = (viewHeight - bmp.getHeight()) / 2;
        if (stY < 0) stY = 0;
        Rect dest = new Rect(stX, stY, bmp.getWidth() + stX, bmp.getHeight() + stY);
        canvas.drawBitmap(bmp, src, dest, paint);
    }

    public static Bitmap rotateBitmap(Bitmap bmp) {
        int bwidth = bmp.getWidth();
        int bheight = bmp.getHeight();
        WeakReference<Bitmap> rotatedImg = null;
        if (bwidth > bheight) {
            Matrix matrix = new Matrix();
            matrix.postRotate(90);
            rotatedImg = new WeakReference<Bitmap>(Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true));
            return rotatedImg.get();
        }
        return bmp;
    }


    public static Bitmap getScaledBitmap(Bitmap bmp, int maxWidth, int maxHeight) {
        if (bmp != null) {
            float aspectRatio = bmp.getWidth() / (float) bmp.getHeight();
            if (bmp.getWidth() > bmp.getHeight()) {
                if (bmp.getWidth() > maxWidth) {
                    int requiredWidth = maxWidth;
                    int requiredHeight = Math.round(requiredWidth / aspectRatio);
                    bmp = Bitmap.createScaledBitmap(bmp, requiredWidth, requiredHeight, true);
                }
            } else if (bmp.getHeight() > bmp.getWidth()) {
                if (bmp.getHeight() > maxHeight) {
                    int requiredHeight = maxHeight;
                    int requiredWidth = Math.round(requiredHeight * aspectRatio);
                    bmp = Bitmap.createScaledBitmap(bmp, requiredWidth, requiredHeight, true);
                }
            }
            return bmp;
        }
        return null;
    }

}
